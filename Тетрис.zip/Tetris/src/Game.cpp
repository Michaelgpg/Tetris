#include "Game.h"
#include <chrono>

const int SHAPES[7][4][4][4] = {{
    // I
    {{0,0,0,0},{1,1,1,1},{0,0,0,0},{0,0,0,0}},
    {{0,0,1,0},{0,0,1,0},{0,0,1,0},{0,0,1,0}},
    {{0,0,0,0},{0,0,0,0},{1,1,1,1},{0,0,0,0}},
    {{0,1,0,0},{0,1,0,0},{0,1,0,0},{0,1,0,0}}
},{
    // O
    {{0,0,0,0},{0,1,1,0},{0,1,1,0},{0,0,0,0}},
    {{0,0,0,0},{0,1,1,0},{0,1,1,0},{0,0,0,0}},
    {{0,0,0,0},{0,1,1,0},{0,1,1,0},{0,0,0,0}},
    {{0,0,0,0},{0,1,1,0},{0,1,1,0},{0,0,0,0}}
},{
    // T
    {{0,0,0,0},{0,1,0,0},{1,1,1,0},{0,0,0,0}},
    {{0,0,0,0},{0,1,0,0},{0,1,1,0},{0,1,0,0}},
    {{0,0,0,0},{0,0,0,0},{1,1,1,0},{0,1,0,0}},
    {{0,0,0,0},{0,1,0,0},{1,1,0,0},{0,1,0,0}}
},{
    // S
    {{0,0,0,0},{0,1,1,0},{1,1,0,0},{0,0,0,0}},
    {{0,0,0,0},{0,1,0,0},{0,1,1,0},{0,0,1,0}},
    {{0,0,0,0},{0,0,0,0},{0,1,1,0},{1,1,0,0}},
    {{1,0,0,0},{1,1,0,0},{0,1,0,0},{0,0,0,0}}
},{
    // Z
    {{0,0,0,0},{1,1,0,0},{0,1,1,0},{0,0,0,0}},
    {{0,0,0,0},{0,0,1,0},{0,1,1,0},{0,1,0,0}},
    {{0,0,0,0},{0,0,0,0},{1,1,0,0},{0,1,1,0}},
    {{0,0,1,0},{0,1,1,0},{0,1,0,0},{0,0,0,0}}
},{
    // J
    {{0,0,0,0},{1,0,0,0},{1,1,1,0},{0,0,0,0}},
    {{0,0,0,0},{0,1,1,0},{0,1,0,0},{0,1,0,0}},
    {{0,0,0,0},{0,0,0,0},{1,1,1,0},{0,0,1,0}},
    {{0,0,0,0},{0,1,0,0},{0,1,0,0},{1,1,0,0}}
},{
    // L
    {{0,0,0,0},{0,0,1,0},{1,1,1,0},{0,0,0,0}},
    {{0,0,0,0},{0,1,0,0},{0,1,0,0},{0,1,1,0}},
    {{0,0,0,0},{0,0,0,0},{1,1,1,0},{1,0,0,0}},
    {{0,0,0,0},{1,1,0,0},{0,1,0,0},{0,1,0,0}}
}};

const sf::Color COLORS[] = {
    sf::Color::Black,
    sf::Color::Cyan,
    sf::Color::Yellow,
    sf::Color(128, 0, 128),
    sf::Color::Green,
    sf::Color::Red,
    sf::Color::Blue,
    sf::Color(255, 165, 0)
};

Game::Game() : score(0), gameOver(false) {
    rng.seed(std::chrono::steady_clock::now().time_since_epoch().count());
    next = randomTetromino();
    spawnNew();
}

Game::Tetromino Game::randomTetromino() {
    std::uniform_int_distribution<int> dist(0, 6);
    return {dist(rng), 0, 3, 0};
}

bool Game::collision(const Tetromino& t) const {
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            if (SHAPES[t.type][t.rotation][i][j]) {
                int x = t.x + j;
                int y = t.y + i;
                if (x < 0 || x >= 10 || y >= 20) return true;
                if (y >= 0 && field[y][x]) return true;
            }
        }
    }
    return false;
}

void Game::merge() {
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            if (SHAPES[current.type][current.rotation][i][j]) {
                int x = current.x + j;
                int y = current.y + i;
                if (y >= 0) field[y][x] = current.type + 1;
            }
        }
    }
}

void Game::clearLines() {
    int cleared = 0;
    for (int y = 19; y >= 0; ) {
        bool full = true;
        for (int x = 0; x < 10; x++) {
            if (!field[y][x]) { full = false; break; }
        }
        if (full) {
            for (int row = y; row > 0; row--)
                field[row] = field[row-1];
            field[0] = {};
            cleared++;
        } else {
            y--;
        }
    }
    if (cleared) {
        score += (cleared == 1 ? 100 : cleared == 2 ? 300 : cleared == 3 ? 500 : 800);
    }
}

void Game::spawnNew() {
    current = next;
    next = randomTetromino();
    if (collision(current)) gameOver = true;
}

void Game::update() {
    if (!gameOver) {
        Tetromino t = current;
        t.y++;
        if (collision(t)) {
            merge();
            clearLines();
            spawnNew();
        } else {
            current = t;
        }
    }
}

void Game::handleInput(sf::Keyboard::Key key) {
    if (key == sf::Keyboard::Key::Left) {
        Tetromino t = current;
        t.x--;
        if (!collision(t)) current = t;
    }
    else if (key == sf::Keyboard::Key::Right) {
        Tetromino t = current;
        t.x++;
        if (!collision(t)) current = t;
    }
    else if (key == sf::Keyboard::Key::Up) {
        Tetromino t = current;
        t.rotation = (t.rotation + 1) % 4;
        if (!collision(t)) current = t;
    }
    else if (key == sf::Keyboard::Key::Space) {
        while (true) {
            Tetromino t = current;
            t.y++;
            if (collision(t)) break;
            current = t;
        }
        merge();
        clearLines();
        spawnNew();
    }
}

void Game::draw(sf::RenderWindow& window) {
    const int S = 30;
    
    for (int y = 0; y < 20; y++) {
        for (int x = 0; x < 10; x++) {
            sf::RectangleShape cell({(float)S - 1, (float)S - 1});
            cell.setPosition({(float)x * S, (float)y * S});
            cell.setFillColor(COLORS[field[y][x]]);
            cell.setOutlineThickness(1);
            cell.setOutlineColor({50, 50, 50});
            window.draw(cell);
        }
    }
    
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            if (SHAPES[current.type][current.rotation][i][j]) {
                int x = current.x + j;
                int y = current.y + i;
                sf::RectangleShape cell({(float)S - 1, (float)S - 1});
                cell.setPosition({(float)x * S, (float)y * S});
                cell.setFillColor(COLORS[current.type + 1]);
                cell.setOutlineThickness(1);
                cell.setOutlineColor({50, 50, 50});
                window.draw(cell);
            }
        }
    }
    
    sf::Font font;
    if (font.openFromFile("/usr/share/fonts/TTF/DejaVuSans.ttf")) {
        sf::Text text(font);
        text.setCharacterSize(24);
        text.setFillColor(sf::Color::White);
        text.setPosition({(float)(10 * S + 10), 10});
        text.setString("Score: " + std::to_string(score));
        window.draw(text);
        
        if (gameOver) {
            text.setString("GAME OVER\nPress R");
            text.setPosition({(float)(10 * S + 10), 60});
            window.draw(text);
        }
        
        text.setString("Next:");
        text.setPosition({(float)(10 * S + 10), 130});
        window.draw(text);
        
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                if (SHAPES[next.type][next.rotation][i][j]) {
                    sf::RectangleShape cell({(float)S - 1, (float)S - 1});
                    cell.setPosition({(float)(10 * S + 10 + j * S), (float)(170 + i * S)});
                    cell.setFillColor(COLORS[next.type + 1]);
                    cell.setOutlineThickness(1);
                    cell.setOutlineColor({50, 50, 50});
                    window.draw(cell);
                }
            }
        }
    }
}

bool Game::isGameOver() const { return gameOver; }
void Game::restart() { *this = Game(); }
int Game::getScore() const { return score; }