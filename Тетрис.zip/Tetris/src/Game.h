#ifndef GAME_H
#define GAME_H

#include <SFML/Graphics.hpp>
#include <array>
#include <random>

class Game {
public:
    Game();
    void update();
    void draw(sf::RenderWindow& window);
    void handleInput(sf::Keyboard::Key key);
    bool isGameOver() const;
    void restart();
    int getScore() const;

private:
    struct Tetromino {
        int type, rotation, x, y;
    };
    
    std::array<std::array<int, 10>, 20> field{};
    Tetromino current, next;
    int score;
    bool gameOver;
    std::mt19937 rng;
    
    Tetromino randomTetromino();
    bool collision(const Tetromino& t) const;
    void merge();
    void clearLines();
    void spawnNew();
};

#endif