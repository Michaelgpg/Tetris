#include "Game.h"

int main() {
    sf::RenderWindow window(sf::VideoMode({10 * 30 + 200, 20 * 30}), "Tetris");
    window.setFramerateLimit(60);
    
    Game game;
    sf::Clock clock;
    float interval = 0.5f;
    
    while (window.isOpen()) {
        while (auto event = window.pollEvent()) {
            if (event->is<sf::Event::Closed>())
                window.close();
            
            if (auto* key = event->getIf<sf::Event::KeyPressed>()) {
                if (!game.isGameOver())
                    game.handleInput(key->code);
                
                if (key->code == sf::Keyboard::Key::R && game.isGameOver())
                    game.restart();
            }
        }
        
        if (!game.isGameOver() && clock.getElapsedTime().asSeconds() >= interval) {
            game.update();
            clock.restart();
        }
        
        window.clear();
        game.draw(window);
        window.display();
    }
    
    return 0;
}